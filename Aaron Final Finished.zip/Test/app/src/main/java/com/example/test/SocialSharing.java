package com.example.test;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class SocialSharing extends AppCompatActivity {
// Button Member Variables
    private Button facebookButton;
    private Button instagramButton;
    private Button twitterButton;
    private Button smsButton;
    private Button emailButton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_social_sharing);


        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);

        bottomNavigationView.setSelectedItemId(R.id.nav_profile);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch (menuItem.getItemId()) {
                    case R.id.nav_recipe:
                        startActivity(new Intent(getApplicationContext()
                                ,Recipe.class));
                        overridePendingTransition(0, 0);
                        return true;
                    case R.id.nav_calorie:
                        startActivity(new Intent(getApplicationContext()
                                ,Calorie.class));
                        overridePendingTransition(0, 0);
                        return true;
                    case R.id.nav_exercise:
                        startActivity(new Intent(getApplicationContext()
                                ,Exercise.class));
                        overridePendingTransition(0, 0);
                        return true;
                    case R.id.nav_profile:
                        startActivity(new Intent(getApplicationContext()
                                ,Profile.class));
                        overridePendingTransition(0, 0);
                        return true;
                    case R.id.nav_home:
                        startActivity(new Intent(getApplicationContext()
                                ,MainActivity.class));
                        overridePendingTransition(0, 0);
                        return true;
                }
                return false;
            }
        });
        facebookButton = (Button) findViewById(R.id.buttonfb);
        facebookButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openFBShareActivity();
            }
        });
        instagramButton = (Button) findViewById(R.id.buttoninsta);
        instagramButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openInstaShareActivity();
            }
        });
        twitterButton = (Button) findViewById(R.id.buttontwitter);
        twitterButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openTwitterShareActivity();
            }
        });
        smsButton = (Button) findViewById(R.id.buttonsms);
        smsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openSMSShareActivity();
            }
        });
        emailButton = (Button) findViewById(R.id.buttonemail);
        emailButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openEmailShareActivity();
            }
        });
    }
    public void openFBShareActivity() {
        Intent intent = new Intent(this, Fb_Share.class);
        startActivity(intent);
    }
    public void openInstaShareActivity() {
        Intent intent = new Intent(this, Insta_Share.class);
        startActivity(intent);
    }
    public void openTwitterShareActivity() {
        Intent intent = new Intent(this, TwitterShare.class);
        startActivity(intent);
    }
    public void openSMSShareActivity() {
        Intent intent = new Intent(this, SMS_Share.class);
        startActivity(intent);
    }
    public void openEmailShareActivity() {
        Intent intent = new Intent(this, Email_Share.class);
        startActivity(intent);
    }
}