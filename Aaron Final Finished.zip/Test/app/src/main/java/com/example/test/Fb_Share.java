package com.example.test;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class Fb_Share extends AppCompatActivity {

    private Button facebook1DayButton;
    private Button facebook1WeekButton;
    private Button facebook1MonthButton;
    private Button facebook6MonthsButton;
    private Button facebook1YearButton;
    private Button facebookMaxButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fb__share);

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);

        bottomNavigationView.setSelectedItemId(R.id.nav_profile);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch (menuItem.getItemId()) {
                    case R.id.nav_recipe:
                        startActivity(new Intent(getApplicationContext()
                                ,Recipe.class));
                        overridePendingTransition(0, 0);
                        return true;
                    case R.id.nav_calorie:
                        startActivity(new Intent(getApplicationContext()
                                ,Calorie.class));
                        overridePendingTransition(0, 0);
                        return true;
                    case R.id.nav_exercise:
                        startActivity(new Intent(getApplicationContext()
                                ,Exercise.class));
                        overridePendingTransition(0, 0);
                        return true;
                    case R.id.nav_profile:
                        startActivity(new Intent(getApplicationContext()
                                ,Profile.class));
                        overridePendingTransition(0, 0);
                        return true;
                    case R.id.nav_home:
                        startActivity(new Intent(getApplicationContext()
                                ,MainActivity.class));
                        overridePendingTransition(0, 0);
                        return true;
                }
                return false;
            }
        });
        facebook1DayButton = (Button) findViewById(R.id.buttonfb1d);
        facebook1DayButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openFB2ShareActivity();
            }
        });
        facebook1WeekButton = (Button) findViewById(R.id.buttonfb1w);
        facebook1WeekButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openFB2ShareActivity();
            }
        });
        facebook1MonthButton = (Button) findViewById(R.id.buttonfb1m);
        facebook1MonthButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openFB2ShareActivity();
            }
        });
        facebook6MonthsButton = (Button) findViewById(R.id.buttonfb6m);
        facebook6MonthsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openFB2ShareActivity();
            }
        });
        facebook1YearButton = (Button) findViewById(R.id.buttonfb1y);
        facebook1YearButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openFB2ShareActivity();
            }
        });
        facebookMaxButton = (Button) findViewById(R.id.buttonfbmax);
        facebookMaxButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openFB2ShareActivity();
            }
        });
    }
    public void openFB2ShareActivity() {
        Intent intent = new Intent(this, FB_Share2.class);
        startActivity(intent);
    }
}