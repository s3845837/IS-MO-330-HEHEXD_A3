package com.example.test;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class TwitterShare2 extends AppCompatActivity {

    private Button twitterNext;
    private Button cals;
    private Button steps;
    private Button weight;
    private Button goals;
    private Button workouts;
    private Button rpoints;
    private Boolean calsIsClicked;
    private Boolean stepIsClicked;
    private Boolean weightIsClicked;
    private Boolean goalIsClicked;
    private Boolean workoutIsClicked;
    private Boolean rpIsClicked;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_twitter_share2);

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);

        bottomNavigationView.setSelectedItemId(R.id.nav_profile);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch (menuItem.getItemId()) {
                    case R.id.nav_recipe:
                        startActivity(new Intent(getApplicationContext()
                                ,Recipe.class));
                        overridePendingTransition(0, 0);
                        return true;
                    case R.id.nav_calorie:
                        startActivity(new Intent(getApplicationContext()
                                ,Calorie.class));
                        overridePendingTransition(0, 0);
                        return true;
                    case R.id.nav_exercise:
                        startActivity(new Intent(getApplicationContext()
                                ,Exercise.class));
                        overridePendingTransition(0, 0);
                        return true;
                    case R.id.nav_profile:
                        startActivity(new Intent(getApplicationContext()
                                ,Profile.class));
                        overridePendingTransition(0, 0);
                        return true;
                    case R.id.nav_home:
                        startActivity(new Intent(getApplicationContext()
                                ,MainActivity.class));
                        overridePendingTransition(0, 0);
                        return true;
                }
                return false;
            }
        });
        twitterNext = (Button) findViewById(R.id.buttontwitternext);
        twitterNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openFinalShareActivity();
            }
        });
        cals = (Button) findViewById(R.id.button45);
        cals.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (calsIsClicked) {
                    cals.setBackgroundDrawable(getResources().getDrawable(R.drawable.ic_greenbutton));
                    calsIsClicked = true;
                } else {
                    cals.setBackgroundDrawable(getResources().getDrawable(R.drawable.ic_aquabutton));
                    calsIsClicked = false;
                }
            }
        });
        steps = (Button) findViewById(R.id.button47);
        steps.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (stepIsClicked) {
                    steps.setBackgroundDrawable(getResources().getDrawable(R.drawable.ic_greenbutton));
                    stepIsClicked = true;
                } else {
                    steps.setBackgroundDrawable(getResources().getDrawable(R.drawable.ic_greybutton));
                    stepIsClicked = false;
                }
            }
        });
        weight = (Button) findViewById(R.id.button50);
        weight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (weightIsClicked) {
                    weight.setBackgroundDrawable(getResources().getDrawable(R.drawable.ic_greenbutton));
                    weightIsClicked = true;
                } else {
                    weight.setBackgroundDrawable(getResources().getDrawable(R.drawable.ic_aquabutton));
                    weightIsClicked = false;
                }
            }
        });
        goals = (Button) findViewById(R.id.button46);
        goals.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (goalIsClicked) {
                    goals.setBackgroundDrawable(getResources().getDrawable(R.drawable.ic_greenbutton));
                    goalIsClicked = true;
                } else {
                    goals.setBackgroundDrawable(getResources().getDrawable(R.drawable.ic_greybutton));
                    goalIsClicked = false;
                }
            }
        });
        workouts = (Button) findViewById(R.id.button48);
        workouts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (workoutIsClicked) {
                    workouts.setBackgroundDrawable(getResources().getDrawable(R.drawable.ic_greenbutton));
                    workoutIsClicked = true;
                } else {
                    workouts.setBackgroundDrawable(getResources().getDrawable(R.drawable.ic_aquabutton));
                    workoutIsClicked = false;
                }
            }
        });
        rpoints = (Button) findViewById(R.id.button51);
        rpoints.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (rpIsClicked) {
                    rpoints.setBackgroundDrawable(getResources().getDrawable(R.drawable.ic_greenbutton));
                    rpIsClicked = true;
                } else {
                    rpoints.setBackgroundDrawable(getResources().getDrawable(R.drawable.ic_greybutton));
                    rpIsClicked = false;
                }
            }
        });
    }
    public void openFinalShareActivity() {
        Intent intent = new Intent(this, FinalShare.class);
        startActivity(intent);
    }
}