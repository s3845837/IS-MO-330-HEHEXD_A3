package com.example.testmvideo;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.VideoView;

public class recLady extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rec_lady);
        final VideoView videoView = (VideoView) findViewById(R.id.video_lady);
        videoView.setVideoPath("android.resource://"+ this.getPackageName()+"/"+R.drawable.fitness);

        videoView.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mediaPlayer) {
                showThumbnail(mediaPlayer);
            }
        });

        Button button = findViewById(R.id.btn_play_l);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                videoView.start();
            }
        });
    }

    private void showThumbnail(MediaPlayer mediaPlayer) {
        mediaPlayer.start();;
        mediaPlayer.pause();
        mediaPlayer.seekTo(0);

    }

}