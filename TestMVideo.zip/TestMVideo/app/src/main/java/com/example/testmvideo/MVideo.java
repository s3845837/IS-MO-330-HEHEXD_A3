package com.example.testmvideo;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class MVideo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_m_video);
    }
}