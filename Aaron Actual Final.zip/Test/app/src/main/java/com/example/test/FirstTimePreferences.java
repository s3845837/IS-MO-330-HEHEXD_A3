package com.example.test;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class FirstTimePreferences extends AppCompatActivity {
    private Button doneButton;
    private EditText enterName;

    public boolean done = false;



    public static final String EXTRA_TEXT = "com.example.application.test.EXTRA_TEXT";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first_time_preferences);

        enterName = (EditText) findViewById(R.id.edittext_entername);
        doneButton = (Button) findViewById(R.id.button_done_setup);

        doneButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String text  = enterName.getText().toString();
                Pattern pattern = Pattern.compile("^(?=.{2,20}$)(?![_.])(?!.*[_.]{2})[a-zA-Z0-9._]+(?<![_.])$", Pattern.CASE_INSENSITIVE);
                Matcher matcher = pattern.matcher(text);
                boolean matchFound = matcher.find();
                if(!matchFound) {
                    showMessage();

                } else {
                    openMainPage();
                }

            }
        });
    }


    public void openMainPage() {
        String text  = enterName.getText().toString();
        Intent intent = new Intent(this, MainActivity.class);
        intent.putExtra(EXTRA_TEXT, text);
        this.done = true;
        startActivity(intent);
    }

    public void showMessage() {
        Toast.makeText(this, "Please fill in the details or enter the valid username", Toast.LENGTH_SHORT).show();
    }
}