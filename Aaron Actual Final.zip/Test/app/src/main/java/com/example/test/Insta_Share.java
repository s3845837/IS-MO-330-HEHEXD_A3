package com.example.test;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class Insta_Share extends AppCompatActivity {

    private Button insta1DayButton;
    private Button insta1WeekButton;
    private Button insta1MonthButton;
    private Button insta6MonthsButton;
    private Button insta1YearButton;
    private Button instaMaxButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insta__share);

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);

        bottomNavigationView.setSelectedItemId(R.id.nav_profile);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch (menuItem.getItemId()) {
                    case R.id.nav_recipe:
                        startActivity(new Intent(getApplicationContext()
                                ,Recipe.class));
                        overridePendingTransition(0, 0);
                        return true;
                    case R.id.nav_calorie:
                        startActivity(new Intent(getApplicationContext()
                                ,Calorie.class));
                        overridePendingTransition(0, 0);
                        return true;
                    case R.id.nav_exercise:
                        startActivity(new Intent(getApplicationContext()
                                ,Exercise.class));
                        overridePendingTransition(0, 0);
                        return true;
                    case R.id.nav_profile:
                        startActivity(new Intent(getApplicationContext()
                                ,Profile.class));
                        overridePendingTransition(0, 0);
                        return true;
                    case R.id.nav_home:
                        startActivity(new Intent(getApplicationContext()
                                ,MainActivity.class));
                        overridePendingTransition(0, 0);
                        return true;
                }
                return false;
            }
        });
        insta1DayButton = (Button) findViewById(R.id.buttoninsta1d);
        insta1DayButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openInsta2ShareActivity();
            }
        });
        insta1WeekButton = (Button) findViewById(R.id.buttoninsta1w);
        insta1WeekButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openInsta2ShareActivity();
            }
        });
        insta1MonthButton = (Button) findViewById(R.id.buttoninsta1m);
        insta1MonthButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openInsta2ShareActivity();
            }
        });
        insta6MonthsButton = (Button) findViewById(R.id.buttoninsta6m);
        insta6MonthsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openInsta2ShareActivity();
            }
        });
        insta1YearButton = (Button) findViewById(R.id.buttoninsta1y);
        insta1YearButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openInsta2ShareActivity();
            }
        });
        instaMaxButton = (Button) findViewById(R.id.buttoninstamax);
        instaMaxButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openInsta2ShareActivity();
            }
        });
    }
    public void openInsta2ShareActivity() {
        Intent intent = new Intent(this, Insta_Share2.class);
        startActivity(intent);
    }
}