package com.example.test;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class Email_Share2 extends AppCompatActivity {

    private Button emailNext;
    private Button emCals;
    private Button emSteps;
    private Button emWeight;
    private Button emGoals;
    private Button emWorkouts;
    private Button emRP;
    private Boolean calsIsClicked;
    private Boolean stepIsClicked;
    private Boolean weightIsClicked;
    private Boolean goalIsClicked;
    private Boolean workoutIsClicked;
    private Boolean rpIsClicked;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_email__share2);

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);

        bottomNavigationView.setSelectedItemId(R.id.nav_profile);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch (menuItem.getItemId()) {
                    case R.id.nav_recipe:
                        startActivity(new Intent(getApplicationContext()
                                ,Recipe.class));
                        overridePendingTransition(0, 0);
                        return true;
                    case R.id.nav_calorie:
                        startActivity(new Intent(getApplicationContext()
                                ,Calorie.class));
                        overridePendingTransition(0, 0);
                        return true;
                    case R.id.nav_exercise:
                        startActivity(new Intent(getApplicationContext()
                                ,Exercise.class));
                        overridePendingTransition(0, 0);
                        return true;
                    case R.id.nav_profile:
                        startActivity(new Intent(getApplicationContext()
                                ,Profile.class));
                        overridePendingTransition(0, 0);
                        return true;
                    case R.id.nav_home:
                        startActivity(new Intent(getApplicationContext()
                                ,MainActivity.class));
                        overridePendingTransition(0, 0);
                        return true;
                }
                return false;
            }
        });
        emailNext = (Button) findViewById(R.id.buttonemailnext);
        emailNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openFinalShareActivity();
            }
        });
        emCals = (Button) findViewById(R.id.button59);
        emCals.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (calsIsClicked) {
                    emCals.setBackgroundDrawable(getResources().getDrawable(R.drawable.ic_greenbutton));
                    calsIsClicked = true;
                } else {
                    emCals.setBackgroundDrawable(getResources().getDrawable(R.drawable.ic_aquabutton));
                    calsIsClicked = false;
                }
            }
        });
        emSteps = (Button) findViewById(R.id.button61);
        emSteps.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (stepIsClicked) {
                    emSteps.setBackgroundDrawable(getResources().getDrawable(R.drawable.ic_greenbutton));
                    stepIsClicked = true;
                } else {
                    emSteps.setBackgroundDrawable(getResources().getDrawable(R.drawable.ic_greybutton));
                    stepIsClicked = false;
                }
            }
        });
        emWeight = (Button) findViewById(R.id.button64);
        emWeight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (weightIsClicked) {
                    emWeight.setBackgroundDrawable(getResources().getDrawable(R.drawable.ic_greenbutton));
                    weightIsClicked = true;
                } else {
                    emWeight.setBackgroundDrawable(getResources().getDrawable(R.drawable.ic_aquabutton));
                    weightIsClicked = false;
                }
            }
        });
        emGoals = (Button) findViewById(R.id.button60);
        emGoals.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (goalIsClicked) {
                    emGoals.setBackgroundDrawable(getResources().getDrawable(R.drawable.ic_greenbutton));
                    goalIsClicked = true;
                } else {
                    emGoals.setBackgroundDrawable(getResources().getDrawable(R.drawable.ic_greybutton));
                    goalIsClicked = false;
                }
            }
        });
        emWorkouts = (Button) findViewById(R.id.button62);
        emWorkouts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (workoutIsClicked) {
                    emWorkouts.setBackgroundDrawable(getResources().getDrawable(R.drawable.ic_greenbutton));
                    workoutIsClicked = true;
                } else {
                    emWorkouts.setBackgroundDrawable(getResources().getDrawable(R.drawable.ic_aquabutton));
                    workoutIsClicked = false;
                }
            }
        });
        emRP = (Button) findViewById(R.id.button65);
        emRP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (rpIsClicked) {
                    emRP.setBackgroundDrawable(getResources().getDrawable(R.drawable.ic_greenbutton));
                    rpIsClicked = true;
                } else {
                    emRP.setBackgroundDrawable(getResources().getDrawable(R.drawable.ic_greybutton));
                    rpIsClicked = false;
                }
            }
        });
    }
    public void openFinalShareActivity() {
        Intent intent = new Intent(this, FinalShare.class);
        startActivity(intent);
    }
}