package com.example.test;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class SMS_Share extends AppCompatActivity {

    private Button sms1DayButton;
    private Button sms1WeekButton;
    private Button sms1MonthButton;
    private Button sms6MonthsButton;
    private Button sms1YearButton;
    private Button smsMaxButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms__share);

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);

        bottomNavigationView.setSelectedItemId(R.id.nav_exercise);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch (menuItem.getItemId()) {
                    case R.id.nav_recipe:
                        startActivity(new Intent(getApplicationContext()
                                ,Recipe.class));
                        overridePendingTransition(0, 0);
                        return true;
                    case R.id.nav_calorie:
                        startActivity(new Intent(getApplicationContext()
                                ,Calorie.class));
                        overridePendingTransition(0, 0);
                        return true;
                    case R.id.nav_exercise:
                        startActivity(new Intent(getApplicationContext()
                                ,Exercise.class));
                        overridePendingTransition(0, 0);
                        return true;
                    case R.id.nav_profile:
                        startActivity(new Intent(getApplicationContext()
                                ,Profile.class));
                        overridePendingTransition(0, 0);
                        return true;
                    case R.id.nav_home:
                        startActivity(new Intent(getApplicationContext()
                                ,MainActivity.class));
                        overridePendingTransition(0, 0);
                        return true;
                }
                return false;
            }
        });
        sms1DayButton = (Button) findViewById(R.id.buttonsms1d);
        sms1DayButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openSms2ShareActivity();
            }
        });
        sms1WeekButton = (Button) findViewById(R.id.buttonsms1w);
        sms1WeekButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openSms2ShareActivity();
            }
        });
        sms1MonthButton = (Button) findViewById(R.id.buttonsms1m);
        sms1MonthButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openSms2ShareActivity();
            }
        });
        sms6MonthsButton = (Button) findViewById(R.id.buttonsms6m);
        sms6MonthsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openSms2ShareActivity();
            }
        });
        sms1YearButton = (Button) findViewById(R.id.buttonsms1y);
        sms1YearButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openSms2ShareActivity();
            }
        });
        smsMaxButton = (Button) findViewById(R.id.buttonsmsmax);
        smsMaxButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openSms2ShareActivity();
            }
        });
    }
    public void openSms2ShareActivity() {
        Intent intent = new Intent(this, SMS_Share2.class);
        startActivity(intent);
    }
}