package com.example.test;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Calendar;

public class Recipe extends AppCompatActivity {
    private Button trendingButton;
    private Button snackButton;
    private Button breakfastButton;
    private Button lunchButton;
    private Button dinnerButton;

    private RequestQueue mQueue;
    private ImageView lunchHeroImg;
    private int indexLunch = 0;
    public static final String INDEXLUNCH = "indexLunch";
    private ImageView trendingHeroImg;
    private int indexTrending = 0;
    public static final String INDEXTRENDING = "indexTrending";
    private ImageView snackHeroImg;
    private int indexSnack = 0;
    public static final String INDEXSNACK = "indexSnack";
    private ImageView breakfastHeroImg;
    private int indexBreakfast = 0;
    public static final String INDEXBREAKFAST = "indexBreakfast";
    private ImageView dinnerHeroImg;
    private int indexDinner = 0;
    public static final String INDEXDINNER = "indexDinner";

    private boolean lunchDoneIsClicked;
    private boolean lunchSkipIsClicked;
    private boolean lunchChangeIsClicked;

    private boolean trendingDoneIsClicked;
    private boolean trendingSkipIsClicked;
    private boolean trendingChangeIsClicked;

    private boolean snackDoneIsClicked;
    private boolean snackSkipIsClicked;
    private boolean snackChangeIsClicked;

    private boolean breakfastDoneIsClicked;
    private boolean breakfastSkipIsClicked;
    private boolean breakfastChangeIsClicked;

    private boolean dinnerDoneIsClicked;
    private boolean dinnerSkipIsClicked;
    private boolean dinnerChangeIsClicked;


    private TextView trendingText;
    private TextView snackText;
    private TextView breakfastText;
    private TextView lunchText;
    private TextView dinnerText;

    private ImageView trendingStatusIcon;
    private ImageView snackStatusIcon;
    private ImageView breakfastStatusIcon;
    private ImageView lunchStatusIcon;
    private ImageView dinnerStatusIcon;

    private Button likeLunchButton;
    private boolean likeLunchIsClicked;
    private Button likeTrendingButton;
    private boolean likeTrendingIsClicked;
    private Button likeSnackButton;
    private boolean likeSnackIsClicked;
    private Button likeBreakfastButton;
    private boolean likeBreakfastIsClicked;
    private Button likeDinnerButton;
    private boolean likeDinnerIsClicked;


    private boolean firstStart;


    public static final String LUNCHHEART = "lunchHeart";
    public static final String lUNCHDONE = "lunchDone";
    public static final String lUNCHCHANGE = "lunchChange";
    public static final String lUNCHSKIP = "lunchSkip";

    public static final String TRENDINGHEART = "trendingHeart";
    public static final String TRENDINGDONE = "trendingDone";
    public static final String TRENDINGCHANGE = "trendingChange";
    public static final String TRENDINGSKIP = "trendingSkip";
    public static final String FIRSTSTART = "firstStart";

    public static final String SNACKHEART = "snackHeart";
    public static final String SNACKDONE = "snackDone";
    public static final String SNACKCHANGE = "snackChange";
    public static final String SNACKSKIP = "snackSkip";

    public static final String BREAKFASTHEART = "breakfastHeart";
    public static final String BREAKFASTDONE = "breakfastDone";
    public static final String BREAKFASTCHANGE = "breakfastChange";
    public static final String BREAKFASTSKIP = "breakfastSkip";

    public static final String DINNERHEART = "dinnerHeart";
    public static final String DINNERDONE = "dinnerDone";
    public static final String DINNERCHANGE = "dinnerChange";
    public static final String DINNERSKIP = "dinnerSkip";

    // Colours
    public static final String DONECOLOUR = "#4BB85C";
    public static final String SKIPCOLOUR = "#D85B62";
    public static final String CHANGECOLOUR = "#5B7ED8";
    public static final String NORMALCOLOUR = "#000000";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recipe);

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);

        bottomNavigationView.setSelectedItemId(R.id.nav_recipe);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch (menuItem.getItemId()) {
                    case R.id.nav_recipe:
                        return true;
                    case R.id.nav_calorie:
                        startActivity(new Intent(getApplicationContext()
                                ,Calorie.class));
                        overridePendingTransition(0, 0);
                        return true;
                    case R.id.nav_exercise:
                        startActivity(new Intent(getApplicationContext()
                                ,Exercise.class));
                        overridePendingTransition(0, 0);
                        return true;
                    case R.id.nav_profile:
                        startActivity(new Intent(getApplicationContext()
                                ,Profile.class));
                        overridePendingTransition(0, 0);
                        return true;
                    case R.id.nav_home:
                        startActivity(new Intent(getApplicationContext()
                                ,MainActivity.class));
                        overridePendingTransition(0, 0);
                        return true;
                }
                return false;
            }
        });
        trendingText = (TextView) findViewById(R.id.text_recipe_trending);
        snackText = (TextView) findViewById(R.id.text_snack_recipe);
        breakfastText = (TextView) findViewById(R.id.text_breakfast_recipe);
        lunchText = (TextView) findViewById(R.id.text_lunch_recipe);
        dinnerText = (TextView) findViewById(R.id.text_dinner_recipe);

        trendingStatusIcon = (ImageView) findViewById(R.id.trending_status_icon);
        snackStatusIcon = (ImageView) findViewById(R.id.snack_status_icon);
        breakfastStatusIcon = (ImageView) findViewById(R.id.breakfast_status_icon);
        lunchStatusIcon = (ImageView) findViewById(R.id.lunch_status_icon);
        dinnerStatusIcon = (ImageView) findViewById(R.id.dinner_status_icon);

        trendingButton = (Button) findViewById(R.id.button_trending_recipe);
        snackButton = (Button) findViewById(R.id.button_snack_recipe);
        breakfastButton = (Button) findViewById(R.id.button_breakfast_recipe);
        lunchButton = (Button) findViewById(R.id.button_lunch_recipe);
        dinnerButton = (Button) findViewById(R.id.button_dinner_recipe);

        lunchHeroImg = (ImageView) findViewById(R.id.recipe_image_lunch);
        trendingHeroImg = (ImageView) findViewById(R.id.recipe_image_trending);
        snackHeroImg = (ImageView) findViewById(R.id.recipe_image_snack);
        breakfastHeroImg = (ImageView) findViewById(R.id.recipe_image_breakfast);
        dinnerHeroImg = (ImageView) findViewById(R.id.recipe_image_dinner);



        likeTrendingButton = (Button) findViewById(R.id.trendingHeartRecipe);
        likeSnackButton = (Button) findViewById(R.id.snackHeartRecipe);
        likeBreakfastButton = (Button) findViewById(R.id.breakfastHeartRecipe);
        likeLunchButton = (Button) findViewById(R.id.lunchHeartRecipe);
        likeDinnerButton = (Button) findViewById(R.id.dinnerHeartRecipe);


        trendingButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openTrendingActivity();
            }
        });
        snackButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openSnackActivity();
            }
        });
        breakfastButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openBreakfastActivity();
            }
        });
        lunchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openLunchActivity();
            }
        });
        dinnerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openDinnerActivity();
            }
        });

        likeTrendingButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (likeTrendingIsClicked) {
                    likeTrendingButton.setBackgroundDrawable(getResources().getDrawable(R.drawable.ic_not_liked_icon));
                    likeTrendingIsClicked = false;
                } else {
                    likeTrendingButton.setBackgroundDrawable(getResources().getDrawable(R.drawable.ic_liked_icon));
                    likeTrendingIsClicked = true;
                }
                saveData();
            }
        });

        likeSnackButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (likeSnackIsClicked) {
                    likeSnackButton.setBackgroundDrawable(getResources().getDrawable(R.drawable.ic_not_liked_icon));
                    likeSnackIsClicked = false;
                } else {
                    likeSnackButton.setBackgroundDrawable(getResources().getDrawable(R.drawable.ic_liked_icon));
                    likeSnackIsClicked = true;
                }
                saveData();
            }
        });

        likeBreakfastButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (likeBreakfastIsClicked) {
                    likeBreakfastButton.setBackgroundDrawable(getResources().getDrawable(R.drawable.ic_not_liked_icon));
                    likeBreakfastIsClicked = false;
                } else {
                    likeBreakfastButton.setBackgroundDrawable(getResources().getDrawable(R.drawable.ic_liked_icon));
                    likeBreakfastIsClicked = true;
                }
                saveData();
            }
        });

        likeLunchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (likeLunchIsClicked) {
                    likeLunchButton.setBackgroundDrawable(getResources().getDrawable(R.drawable.ic_not_liked_icon));
                    likeLunchIsClicked = false;
                } else {
                    likeLunchButton.setBackgroundDrawable(getResources().getDrawable(R.drawable.ic_liked_icon));
                    likeLunchIsClicked = true;
                }
                saveData();
            }
        });
        likeDinnerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (likeDinnerIsClicked) {
                    likeDinnerButton.setBackgroundDrawable(getResources().getDrawable(R.drawable.ic_not_liked_icon));
                    likeDinnerIsClicked = false;
                } else {
                    likeDinnerButton.setBackgroundDrawable(getResources().getDrawable(R.drawable.ic_liked_icon));
                    likeDinnerIsClicked = true;
                }
                saveData();
            }
        });

        Calendar calendar = Calendar.getInstance();
        int timeofDay = calendar.get(Calendar.HOUR_OF_DAY);
        if (timeofDay > 22 && !trendingSkipIsClicked && !trendingChangeIsClicked && !trendingDoneIsClicked) {
            trendingSkipIsClicked = true;
        }
        if (timeofDay > 23 && !snackSkipIsClicked && !snackChangeIsClicked && !snackDoneIsClicked) {
            snackSkipIsClicked = true;
        }
        if (timeofDay >= 12 && !breakfastSkipIsClicked && !breakfastChangeIsClicked && !breakfastDoneIsClicked) {
            breakfastSkipIsClicked = true;
        }

        if (timeofDay > 16 && !lunchSkipIsClicked && !lunchChangeIsClicked && !lunchDoneIsClicked) {
            lunchSkipIsClicked = true;
        }
        if (timeofDay > 23 && !dinnerSkipIsClicked && !dinnerChangeIsClicked && !dinnerDoneIsClicked) {
            dinnerSkipIsClicked = true;
        }

        if ((trendingDoneIsClicked && trendingChangeIsClicked) || (trendingDoneIsClicked && !trendingChangeIsClicked)) {
            trendingText.setTextColor(Color.parseColor(DONECOLOUR));
            trendingStatusIcon.setImageResource(R.drawable.ic_tick_24px);
            trendingButton.setBackgroundDrawable(getResources().getDrawable(R.drawable.recipe_button_full_gradient));
        } else if (trendingChangeIsClicked && !trendingDoneIsClicked && !trendingSkipIsClicked) {
            trendingText.setTextColor(Color.parseColor(CHANGECOLOUR));
            trendingStatusIcon.setImageResource(R.drawable.ic_change_24px);
            trendingButton.setBackgroundDrawable(getResources().getDrawable(R.drawable.recipe_button_gradient));
        } else if ((trendingSkipIsClicked && trendingChangeIsClicked) || (trendingSkipIsClicked && !trendingChangeIsClicked)) {
            trendingText.setTextColor(Color.parseColor(SKIPCOLOUR));
            trendingStatusIcon.setImageResource(R.drawable.ic_skip_24px);
            trendingButton.setBackgroundDrawable(getResources().getDrawable(R.drawable.recipe_button_full_gradient));
        } else {
            trendingText.setTextColor(Color.parseColor(NORMALCOLOUR));
            trendingStatusIcon.setImageResource(android.R.color.transparent);
            trendingButton.setBackgroundDrawable(getResources().getDrawable(R.drawable.recipe_button_gradient));
        }

        if ((snackDoneIsClicked && snackChangeIsClicked) || (snackDoneIsClicked && !snackChangeIsClicked)) {
            snackText.setTextColor(Color.parseColor(DONECOLOUR));
            snackStatusIcon.setImageResource(R.drawable.ic_tick_24px);
            snackButton.setBackgroundDrawable(getResources().getDrawable(R.drawable.recipe_button_full_gradient));
        } else if (snackChangeIsClicked && !snackDoneIsClicked && !snackSkipIsClicked) {
            snackText.setTextColor(Color.parseColor(CHANGECOLOUR));
            snackStatusIcon.setImageResource(R.drawable.ic_change_24px);
            snackButton.setBackgroundDrawable(getResources().getDrawable(R.drawable.recipe_button_gradient));
        } else if ((snackSkipIsClicked && snackChangeIsClicked) || (snackSkipIsClicked && !snackChangeIsClicked)) {
            snackText.setTextColor(Color.parseColor(SKIPCOLOUR));
            snackStatusIcon.setImageResource(R.drawable.ic_skip_24px);
            snackButton.setBackgroundDrawable(getResources().getDrawable(R.drawable.recipe_button_full_gradient));
        } else {
            snackText.setTextColor(Color.parseColor(NORMALCOLOUR));
            snackStatusIcon.setImageResource(android.R.color.transparent);
            snackButton.setBackgroundDrawable(getResources().getDrawable(R.drawable.recipe_button_gradient));
        }

        if ((breakfastDoneIsClicked && breakfastChangeIsClicked) || (breakfastDoneIsClicked && !breakfastChangeIsClicked)) {
            breakfastText.setTextColor(Color.parseColor(DONECOLOUR));
            breakfastStatusIcon.setImageResource(R.drawable.ic_tick_24px);
            breakfastButton.setBackgroundDrawable(getResources().getDrawable(R.drawable.recipe_button_full_gradient));
        } else if (breakfastChangeIsClicked && !breakfastDoneIsClicked && !breakfastSkipIsClicked) {
            breakfastText.setTextColor(Color.parseColor(CHANGECOLOUR));
            breakfastStatusIcon.setImageResource(R.drawable.ic_change_24px);
            breakfastButton.setBackgroundDrawable(getResources().getDrawable(R.drawable.recipe_button_gradient));
        } else if ((breakfastSkipIsClicked && breakfastChangeIsClicked) || (breakfastSkipIsClicked && !breakfastChangeIsClicked)) {
            breakfastText.setTextColor(Color.parseColor(SKIPCOLOUR));
            breakfastStatusIcon.setImageResource(R.drawable.ic_skip_24px);
            breakfastButton.setBackgroundDrawable(getResources().getDrawable(R.drawable.recipe_button_full_gradient));
        } else {
            breakfastText.setTextColor(Color.parseColor(NORMALCOLOUR));
            breakfastStatusIcon.setImageResource(android.R.color.transparent);
            breakfastButton.setBackgroundDrawable(getResources().getDrawable(R.drawable.recipe_button_gradient));
        }

        if ((lunchDoneIsClicked && lunchChangeIsClicked) || (lunchDoneIsClicked && !lunchChangeIsClicked)) {
            lunchText.setTextColor(Color.parseColor(DONECOLOUR));
            lunchStatusIcon.setImageResource(R.drawable.ic_tick_24px);
            lunchButton.setBackgroundDrawable(getResources().getDrawable(R.drawable.recipe_button_full_gradient));
        } else if (lunchChangeIsClicked && !lunchDoneIsClicked && !lunchSkipIsClicked) {
            lunchText.setTextColor(Color.parseColor(CHANGECOLOUR));
            lunchStatusIcon.setImageResource(R.drawable.ic_change_24px);
            lunchButton.setBackgroundDrawable(getResources().getDrawable(R.drawable.recipe_button_gradient));
        } else if ((lunchSkipIsClicked && lunchChangeIsClicked) || (lunchSkipIsClicked && !lunchChangeIsClicked)) {
            lunchText.setTextColor(Color.parseColor(SKIPCOLOUR));
            lunchStatusIcon.setImageResource(R.drawable.ic_skip_24px);
            lunchButton.setBackgroundDrawable(getResources().getDrawable(R.drawable.recipe_button_full_gradient));
        } else {
            lunchText.setTextColor(Color.parseColor(NORMALCOLOUR));
            lunchStatusIcon.setImageResource(android.R.color.transparent);
            lunchButton.setBackgroundDrawable(getResources().getDrawable(R.drawable.recipe_button_gradient));
        }

        if ((dinnerDoneIsClicked && dinnerChangeIsClicked) || (dinnerDoneIsClicked && !dinnerChangeIsClicked)) {
            dinnerText.setTextColor(Color.parseColor(DONECOLOUR));
            dinnerStatusIcon.setImageResource(R.drawable.ic_tick_24px);
            dinnerButton.setBackgroundDrawable(getResources().getDrawable(R.drawable.recipe_button_full_gradient));
        } else if (dinnerChangeIsClicked && !dinnerDoneIsClicked && !dinnerSkipIsClicked) {
            dinnerText.setTextColor(Color.parseColor(CHANGECOLOUR));
            dinnerStatusIcon.setImageResource(R.drawable.ic_change_24px);
            dinnerButton.setBackgroundDrawable(getResources().getDrawable(R.drawable.recipe_button_gradient));
        } else if ((dinnerSkipIsClicked && dinnerChangeIsClicked) || (dinnerSkipIsClicked && !dinnerChangeIsClicked)) {
            dinnerText.setTextColor(Color.parseColor(SKIPCOLOUR));
            dinnerStatusIcon.setImageResource(R.drawable.ic_skip_24px);
            dinnerButton.setBackgroundDrawable(getResources().getDrawable(R.drawable.recipe_button_full_gradient));
        } else {
            dinnerText.setTextColor(Color.parseColor(NORMALCOLOUR));
            dinnerStatusIcon.setImageResource(android.R.color.transparent);
            dinnerButton.setBackgroundDrawable(getResources().getDrawable(R.drawable.recipe_button_gradient));
        }

        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        firstStart = prefs.getBoolean(FIRSTSTART, true);
        if (firstStart) {
            saveData();
        } else {
            loadData();
        }
        mQueue = Volley.newRequestQueue(this);
        jsonParse();
    }

    public void openTrendingActivity() {
        Intent intent = new Intent(this, Trending.class);
        startActivity(intent);
    }

    public void openSnackActivity() {
        Intent intent = new Intent(this, Snack.class);
        startActivity(intent);
    }

    public void openBreakfastActivity() {
        Intent intent = new Intent(this, Breakfast.class);
        startActivity(intent);
    }

    public void openLunchActivity() {
        Intent intent = new Intent(this, Lunch.class);
        startActivity(intent);
    }

    public void openDinnerActivity() {
        Intent intent = new Intent(this, Dinner.class);
        startActivity(intent);
    }

    public void loadData() {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        indexLunch = sharedPreferences.getInt(INDEXLUNCH, 0);
        indexTrending = sharedPreferences.getInt(INDEXTRENDING, 0);
        indexSnack = sharedPreferences.getInt(INDEXSNACK, 0);
        indexBreakfast = sharedPreferences.getInt(INDEXBREAKFAST, 0);
        indexDinner = sharedPreferences.getInt(INDEXDINNER, 0);

        likeTrendingIsClicked = sharedPreferences.getBoolean(TRENDINGHEART, false);
        trendingDoneIsClicked = sharedPreferences.getBoolean(TRENDINGDONE, false);
        trendingSkipIsClicked = sharedPreferences.getBoolean(TRENDINGSKIP, false);
        trendingChangeIsClicked = sharedPreferences.getBoolean(TRENDINGCHANGE, false);

        likeSnackIsClicked = sharedPreferences.getBoolean(SNACKHEART, false);
        snackDoneIsClicked = sharedPreferences.getBoolean(SNACKDONE, false);
        snackSkipIsClicked = sharedPreferences.getBoolean(SNACKSKIP, false);
        snackChangeIsClicked = sharedPreferences.getBoolean(SNACKCHANGE, false);

        likeBreakfastIsClicked = sharedPreferences.getBoolean(BREAKFASTHEART, false);
        breakfastDoneIsClicked = sharedPreferences.getBoolean(BREAKFASTDONE, false);
        breakfastSkipIsClicked = sharedPreferences.getBoolean(BREAKFASTSKIP, false);
        breakfastChangeIsClicked = sharedPreferences.getBoolean(BREAKFASTCHANGE, false);

        likeLunchIsClicked = sharedPreferences.getBoolean(LUNCHHEART, false);
        lunchDoneIsClicked = sharedPreferences.getBoolean(lUNCHDONE, false);
        lunchSkipIsClicked = sharedPreferences.getBoolean(lUNCHSKIP, false);
        lunchChangeIsClicked = sharedPreferences.getBoolean(lUNCHCHANGE, false);

        likeSnackIsClicked = sharedPreferences.getBoolean(SNACKHEART, false);
        snackDoneIsClicked = sharedPreferences.getBoolean(SNACKDONE, false);
        snackSkipIsClicked = sharedPreferences.getBoolean(SNACKSKIP, false);
        snackChangeIsClicked = sharedPreferences.getBoolean(SNACKCHANGE, false);


        if(likeTrendingIsClicked) {
            likeTrendingButton.setBackgroundDrawable(getResources().getDrawable(R.drawable.ic_liked_icon));
        } else {
            likeTrendingButton.setBackgroundDrawable(getResources().getDrawable(R.drawable.ic_not_liked_icon));
        }
        if(likeSnackIsClicked) {
            likeSnackButton.setBackgroundDrawable(getResources().getDrawable(R.drawable.ic_liked_icon));
        } else {
            likeSnackButton.setBackgroundDrawable(getResources().getDrawable(R.drawable.ic_not_liked_icon));
        }
        if(likeBreakfastIsClicked) {
            likeBreakfastButton.setBackgroundDrawable(getResources().getDrawable(R.drawable.ic_liked_icon));
        } else {
            likeBreakfastButton.setBackgroundDrawable(getResources().getDrawable(R.drawable.ic_not_liked_icon));
        }
        if(likeLunchIsClicked) {
            likeLunchButton.setBackgroundDrawable(getResources().getDrawable(R.drawable.ic_liked_icon));
        } else {
            likeLunchButton.setBackgroundDrawable(getResources().getDrawable(R.drawable.ic_not_liked_icon));
        }
        if(likeDinnerIsClicked) {
            likeDinnerButton.setBackgroundDrawable(getResources().getDrawable(R.drawable.ic_liked_icon));
        } else {
            likeDinnerButton.setBackgroundDrawable(getResources().getDrawable(R.drawable.ic_not_liked_icon));
        }

        Calendar calendar = Calendar.getInstance();
        int timeofDay = calendar.get(Calendar.HOUR_OF_DAY);
        if (timeofDay > 22 && !trendingSkipIsClicked && !trendingChangeIsClicked && !trendingDoneIsClicked) {
            trendingSkipIsClicked = true;
        }
        if (timeofDay > 23 && !snackSkipIsClicked && !snackChangeIsClicked && !snackDoneIsClicked) {
            snackSkipIsClicked = true;
        }
        if (timeofDay >= 12 && !breakfastSkipIsClicked && !breakfastChangeIsClicked && !breakfastDoneIsClicked) {
            breakfastSkipIsClicked = true;
        }

        if (timeofDay > 16 && !lunchSkipIsClicked && !lunchChangeIsClicked && !lunchDoneIsClicked) {
            lunchSkipIsClicked = true;
        }
        if (timeofDay > 23 && !dinnerSkipIsClicked && !dinnerChangeIsClicked && !dinnerDoneIsClicked) {
            dinnerSkipIsClicked = true;
        }
        if ((trendingDoneIsClicked && trendingChangeIsClicked) || (trendingDoneIsClicked && !trendingChangeIsClicked)) {
            trendingText.setTextColor(Color.parseColor(DONECOLOUR));
            trendingStatusIcon.setImageResource(R.drawable.ic_tick_24px);
            trendingButton.setBackgroundDrawable(getResources().getDrawable(R.drawable.recipe_button_full_gradient));
        } else if (trendingChangeIsClicked && !trendingDoneIsClicked && !trendingSkipIsClicked) {
            trendingText.setTextColor(Color.parseColor(CHANGECOLOUR));
            trendingStatusIcon.setImageResource(R.drawable.ic_change_24px);
            trendingButton.setBackgroundDrawable(getResources().getDrawable(R.drawable.recipe_button_gradient));
        } else if ((trendingSkipIsClicked && trendingChangeIsClicked) || (trendingSkipIsClicked && !trendingChangeIsClicked)) {
            trendingText.setTextColor(Color.parseColor(SKIPCOLOUR));
            trendingStatusIcon.setImageResource(R.drawable.ic_skip_24px);
            trendingButton.setBackgroundDrawable(getResources().getDrawable(R.drawable.recipe_button_full_gradient));
        } else {
            trendingText.setTextColor(Color.parseColor(NORMALCOLOUR));
            trendingStatusIcon.setImageResource(android.R.color.transparent);
            trendingButton.setBackgroundDrawable(getResources().getDrawable(R.drawable.recipe_button_gradient));
        }

        if ((snackDoneIsClicked && snackChangeIsClicked) || (snackDoneIsClicked && !snackChangeIsClicked)) {
            snackText.setTextColor(Color.parseColor(DONECOLOUR));
            snackStatusIcon.setImageResource(R.drawable.ic_tick_24px);
            snackButton.setBackgroundDrawable(getResources().getDrawable(R.drawable.recipe_button_full_gradient));
        } else if (snackChangeIsClicked && !snackDoneIsClicked && !snackSkipIsClicked) {
            snackText.setTextColor(Color.parseColor(CHANGECOLOUR));
            snackStatusIcon.setImageResource(R.drawable.ic_change_24px);
            snackButton.setBackgroundDrawable(getResources().getDrawable(R.drawable.recipe_button_gradient));
        } else if ((snackSkipIsClicked && snackChangeIsClicked) || (snackSkipIsClicked && !snackChangeIsClicked)) {
            snackText.setTextColor(Color.parseColor(SKIPCOLOUR));
            snackStatusIcon.setImageResource(R.drawable.ic_skip_24px);
            snackButton.setBackgroundDrawable(getResources().getDrawable(R.drawable.recipe_button_full_gradient));
        } else {
            snackText.setTextColor(Color.parseColor(NORMALCOLOUR));
            snackStatusIcon.setImageResource(android.R.color.transparent);
            snackButton.setBackgroundDrawable(getResources().getDrawable(R.drawable.recipe_button_gradient));
        }

        if ((breakfastDoneIsClicked && breakfastChangeIsClicked) || (breakfastDoneIsClicked && !breakfastChangeIsClicked)) {
            breakfastText.setTextColor(Color.parseColor(DONECOLOUR));
            breakfastStatusIcon.setImageResource(R.drawable.ic_tick_24px);
            breakfastButton.setBackgroundDrawable(getResources().getDrawable(R.drawable.recipe_button_full_gradient));
        } else if (breakfastChangeIsClicked && !breakfastDoneIsClicked && !breakfastSkipIsClicked) {
            breakfastText.setTextColor(Color.parseColor(CHANGECOLOUR));
            breakfastStatusIcon.setImageResource(R.drawable.ic_change_24px);
            breakfastButton.setBackgroundDrawable(getResources().getDrawable(R.drawable.recipe_button_gradient));
        } else if ((breakfastSkipIsClicked && breakfastChangeIsClicked) || (breakfastSkipIsClicked && !breakfastChangeIsClicked)) {
            breakfastText.setTextColor(Color.parseColor(SKIPCOLOUR));
            breakfastStatusIcon.setImageResource(R.drawable.ic_skip_24px);
            breakfastButton.setBackgroundDrawable(getResources().getDrawable(R.drawable.recipe_button_full_gradient));
        } else {
            breakfastText.setTextColor(Color.parseColor(NORMALCOLOUR));
            breakfastStatusIcon.setImageResource(android.R.color.transparent);
            breakfastButton.setBackgroundDrawable(getResources().getDrawable(R.drawable.recipe_button_gradient));
        }

        if ((lunchDoneIsClicked && lunchChangeIsClicked) || (lunchDoneIsClicked && !lunchChangeIsClicked)) {
            lunchText.setTextColor(Color.parseColor(DONECOLOUR));
            lunchStatusIcon.setImageResource(R.drawable.ic_tick_24px);
            lunchButton.setBackgroundDrawable(getResources().getDrawable(R.drawable.recipe_button_full_gradient));
        } else if (lunchChangeIsClicked && !lunchDoneIsClicked && !lunchSkipIsClicked) {
            lunchText.setTextColor(Color.parseColor(CHANGECOLOUR));
            lunchStatusIcon.setImageResource(R.drawable.ic_change_24px);
            lunchButton.setBackgroundDrawable(getResources().getDrawable(R.drawable.recipe_button_gradient));
        } else if ((lunchSkipIsClicked && lunchChangeIsClicked) || (lunchSkipIsClicked && !lunchChangeIsClicked)) {
            lunchText.setTextColor(Color.parseColor(SKIPCOLOUR));
            lunchStatusIcon.setImageResource(R.drawable.ic_skip_24px);
            lunchButton.setBackgroundDrawable(getResources().getDrawable(R.drawable.recipe_button_full_gradient));
        } else {
            lunchText.setTextColor(Color.parseColor(NORMALCOLOUR));
            lunchStatusIcon.setImageResource(android.R.color.transparent);
            lunchButton.setBackgroundDrawable(getResources().getDrawable(R.drawable.recipe_button_gradient));
        }

        if ((dinnerDoneIsClicked && dinnerChangeIsClicked) || (dinnerDoneIsClicked && !dinnerChangeIsClicked)) {
            dinnerText.setTextColor(Color.parseColor(DONECOLOUR));
            dinnerStatusIcon.setImageResource(R.drawable.ic_tick_24px);
            dinnerButton.setBackgroundDrawable(getResources().getDrawable(R.drawable.recipe_button_full_gradient));
        } else if (dinnerChangeIsClicked && !dinnerDoneIsClicked && !dinnerSkipIsClicked) {
            dinnerText.setTextColor(Color.parseColor(CHANGECOLOUR));
            dinnerStatusIcon.setImageResource(R.drawable.ic_change_24px);
            dinnerButton.setBackgroundDrawable(getResources().getDrawable(R.drawable.recipe_button_gradient));
        } else if ((dinnerSkipIsClicked && dinnerChangeIsClicked) || (dinnerSkipIsClicked && !dinnerChangeIsClicked)) {
            dinnerText.setTextColor(Color.parseColor(SKIPCOLOUR));
            dinnerStatusIcon.setImageResource(R.drawable.ic_skip_24px);
            dinnerButton.setBackgroundDrawable(getResources().getDrawable(R.drawable.recipe_button_full_gradient));
        } else {
            dinnerText.setTextColor(Color.parseColor(NORMALCOLOUR));
            dinnerStatusIcon.setImageResource(android.R.color.transparent);
            dinnerButton.setBackgroundDrawable(getResources().getDrawable(R.drawable.recipe_button_gradient));
        }

    }

    public void saveData() {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        if (firstStart) {
            editor.putBoolean(FIRSTSTART, false);
        }
        editor.putInt(INDEXLUNCH, indexLunch);
        editor.putInt(INDEXTRENDING, indexTrending);
        editor.putInt(INDEXSNACK, indexSnack);
        editor.putInt(INDEXBREAKFAST, indexBreakfast);
        editor.putInt(INDEXDINNER, indexDinner);

        editor.putBoolean(TRENDINGHEART, likeTrendingIsClicked);
        editor.putBoolean(TRENDINGDONE, trendingDoneIsClicked);
        editor.putBoolean(TRENDINGSKIP, trendingSkipIsClicked);
        editor.putBoolean(TRENDINGCHANGE, trendingChangeIsClicked);

        editor.putBoolean(SNACKHEART, likeSnackIsClicked);
        editor.putBoolean(SNACKDONE, snackDoneIsClicked);
        editor.putBoolean(SNACKSKIP, snackSkipIsClicked);
        editor.putBoolean(SNACKCHANGE, snackChangeIsClicked);

        editor.putBoolean(BREAKFASTHEART, likeBreakfastIsClicked);
        editor.putBoolean(BREAKFASTDONE, breakfastDoneIsClicked);
        editor.putBoolean(BREAKFASTSKIP, breakfastSkipIsClicked);
        editor.putBoolean(BREAKFASTCHANGE, breakfastChangeIsClicked);

        editor.putBoolean(LUNCHHEART, likeLunchIsClicked);
        editor.putBoolean(lUNCHDONE, lunchDoneIsClicked);
        editor.putBoolean(lUNCHSKIP, lunchSkipIsClicked);
        editor.putBoolean(lUNCHCHANGE, lunchChangeIsClicked);

        editor.putBoolean(DINNERHEART, likeDinnerIsClicked);
        editor.putBoolean(DINNERDONE, dinnerDoneIsClicked);
        editor.putBoolean(DINNERSKIP, dinnerSkipIsClicked);
        editor.putBoolean(DINNERCHANGE, dinnerChangeIsClicked);

        editor.apply();

    }

    // When gone back this loads up
    @Override
    protected void onResume() {
        super.onResume();
        loadData();
        jsonParse();
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);
        bottomNavigationView.setSelectedItemId(R.id.nav_recipe);
    }
    @Override
    public void finish() {
        super.finish();
        overridePendingTransition(0, 0);
    }
    private void jsonParse() {
        jsonTrendingParse();
        jsonSnackParse();
        jsonBreakfastParse();
        jsonLunchParse();
        jsonDinnerParse();
    }


    private void jsonLunchParse() {
        String url = "https://hehexda3.s3.amazonaws.com/data/recipe.json";
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            JSONArray jsonArray = response.getJSONArray("lunch");

                            if (indexLunch + 1 > jsonArray.length()) {
                                indexLunch = 0;
                            }
                            JSONObject lunch = jsonArray.getJSONObject(indexLunch);
                            String recipeName = lunch.getString("name");
                            lunchButton.setText(recipeName);
                            if (indexLunch == 0) {
                                lunchHeroImg.setImageResource(R.drawable.chicken_caesar_veggie_wraps);
                            } else if (indexLunch == 1) {
                                lunchHeroImg.setImageResource(R.drawable.chunky_gazpacho_with_rice);
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });
        mQueue.add(request);
    }

    private void jsonTrendingParse() {
        String url = "https://hehexda3.s3.amazonaws.com/data/recipe.json";
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            JSONArray jsonArray = response.getJSONArray("trending");
                            if (indexTrending + 1 > jsonArray.length()) {
                                indexTrending = 0;
                            }
                            JSONObject trending = jsonArray.getJSONObject(indexTrending);
                            String recipeName = trending.getString("name");
                            trendingButton.setText(recipeName);
                            if (indexTrending == 0) {
                                trendingHeroImg.setImageResource(R.drawable.weet_bix_and_mango_smoothie_bowl);
                            } else if (indexTrending == 1) {
                                trendingHeroImg.setImageResource(R.drawable.peppered_steak_with_creamy_mushroom_sauce);
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });
        mQueue.add(request);
    }

    private void jsonSnackParse() {
        String url = "https://hehexda3.s3.amazonaws.com/data/recipe.json";
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            JSONArray jsonArray = response.getJSONArray("snack");
                            if (indexSnack + 1 > jsonArray.length()) {
                                indexSnack = 0;
                            }
                            JSONObject snack = jsonArray.getJSONObject(indexSnack);
                            String recipeName = snack.getString("name");
                            snackButton.setText(recipeName);
                            if (indexSnack == 0) {
                                snackHeroImg.setImageResource(R.drawable.fruit_and_nut_snack_mix);
                            } else if (indexSnack == 1) {
                                snackHeroImg.setImageResource(R.drawable.snack_box_muffins);
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });
        mQueue.add(request);
    }

    private void jsonBreakfastParse() {
        String url = "https://hehexda3.s3.amazonaws.com/data/recipe.json";
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            JSONArray jsonArray = response.getJSONArray("breakfast");

                            if (indexBreakfast + 1 > jsonArray.length()) {
                                indexBreakfast = 0;
                            }
                            JSONObject breakfast = jsonArray.getJSONObject(indexBreakfast);
                            String recipeName = breakfast.getString("name");
                            breakfastButton.setText(recipeName);
                            if (indexBreakfast == 0) {
                                breakfastHeroImg.setImageResource(R.drawable.fruity_smoothie_bowl);
                            } else if (indexBreakfast == 1) {
                                breakfastHeroImg.setImageResource(R.drawable.smoked_salmon_toasts);
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });
        mQueue.add(request);
    }

    private void jsonDinnerParse() {
        String url = "https://hehexda3.s3.amazonaws.com/data/recipe.json";
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            JSONArray jsonArray = response.getJSONArray("dinner");

                            if (indexDinner + 1 > jsonArray.length()) {
                                indexDinner = 0;
                            }
                            JSONObject dinner = jsonArray.getJSONObject(indexDinner);
                            String recipeName = dinner.getString("name");
                            dinnerButton.setText(recipeName);
                            if (indexDinner == 0) {
                                dinnerHeroImg.setImageResource(R.drawable.cajun_style_beef_with_corn_mash);
                            } else if (indexDinner == 1) {
                                dinnerHeroImg.setImageResource(R.drawable.teriyaki_fried_rice_with_omelettep);
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });
        mQueue.add(request);
    }

}