package com.example.test;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity {
    private Button recommendButton;
    private Button trendingButton;
    private Button lunchButton;
    private Button dinnerButton;
    private TextView userGreetings;
    private String username;

    public static final String TEXT = "text";


    private String text = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        boolean firststart = prefs.getBoolean("firstStart", true);
        boolean firststart2 = prefs.getBoolean("firstStart2", true);
        if (firststart) {
            showSetup();
        } else if (!firststart) {
            setContentView(R.layout.activity_main);
            BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);

            bottomNavigationView.setSelectedItemId(R.id.nav_home);

            bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
                @Override
                public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                    switch (menuItem.getItemId()) {
                        case R.id.nav_recipe:
                            startActivity(new Intent(getApplicationContext()
                                    ,Recipe.class));
                            overridePendingTransition(0, 0);
                            return true;
                        case R.id.nav_calorie:
                            startActivity(new Intent(getApplicationContext()
                                    ,Calorie.class));
                            overridePendingTransition(0, 0);
                            return true;
                        case R.id.nav_exercise:
                            startActivity(new Intent(getApplicationContext()
                                    ,Exercise.class));
                            overridePendingTransition(0, 0);
                            return true;
                        case R.id.nav_profile:
                            startActivity(new Intent(getApplicationContext()
                                    ,Profile.class));
                            overridePendingTransition(0, 0);
                            return true;
                        case R.id.nav_home:
                            return true;
                    }
                    return false;
                }
            });
            Intent intent = getIntent();
            username = intent.getStringExtra(FirstTimePreferences.EXTRA_TEXT);
        if (firststart2) {
            saveData();
            setup();
        }
            SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
            text = sharedPreferences.getString(TEXT, "");

            userGreetings = findViewById(R.id.text_greeting_home);
            Calendar calendar = Calendar.getInstance();
            int timeofDay = calendar.get(Calendar.HOUR_OF_DAY);
            if(timeofDay >= 0 && timeofDay <12){
                userGreetings.setText("Good Morning, " + text);
            }
            else if(timeofDay >=12 && timeofDay <16){
                userGreetings.setText("Good Afternoon, " + text);
            }
            else if(timeofDay >=16 && timeofDay <21){
                userGreetings.setText("Good Evening, " + text);
            }
            else if(timeofDay >=21 && timeofDay <24){
                userGreetings.setText("Good Night, " + text);
            }
            recommendButton = (Button) findViewById(R.id.button_recommended_home);
            trendingButton = (Button) findViewById(R.id.button_trending_home);
            lunchButton = (Button) findViewById(R.id.button_lunch_home);
            dinnerButton = (Button) findViewById(R.id.button_dinner_home);

            recommendButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    openSnack();
                }
            });
            trendingButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    openTrending();
                }
            });
            lunchButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    openLunch();
                }
            });
            dinnerButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    openDinner();
                }
            });
        }
    }

    public void openSnack() {
        Intent intent = new Intent(this, Snack.class);
        startActivity(intent);
    }
    public void openTrending() {
        Intent intent = new Intent(this, Trending.class);
        startActivity(intent);
    }
    public void openLunch() {
        Intent intent = new Intent(this, Lunch.class);
        startActivity(intent);
    }
    public void openDinner() {
        Intent intent = new Intent(this, Dinner.class);
        startActivity(intent);
    }

    private void showSetup() {
        Intent intent = new Intent(this, FirstTimePreferences.class);
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putBoolean("firstStart", false);
        editor.apply();
        startActivity(intent);
    }

    private void setup() {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putBoolean("firstStart2", false);
        editor.apply();
    }

    public void saveData() {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(TEXT, username);
        editor.apply();
    }

    @Override
    protected void onResume() {
        super.onResume();
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);
        bottomNavigationView.setSelectedItemId(R.id.nav_home);
    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransition(0, 0);
    }
}