package com.example.test;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.text.Html;
import android.text.method.LinkMovementMethod;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class Trending extends AppCompatActivity {
    private RequestQueue mQueue;
    private ImageView heroImg;
    private TextView title;
    private TextView summary;
    private TextView source;
    private TextView ingredients;
    private TextView instructions;
    private TextView nutrition;
    private TextView notes;
    private int index = 0;


    private Button closeTrendingButton;
    private Button doneButton;
    private boolean doneIsClicked;
    private Button skipButton;
    private boolean skipIsClicked;
    private Button changeButton;
    private boolean changeIsClicked;
    private Button likeButton;
    private boolean likeIsClicked;

    private boolean firstStart;
    public static final String INDEXTRENDING = "indexTrending";
    public static final String FIRSTSTART = "firstStart";
    public static final String TRENDINGHEART = "trendingHeart";
    public static final String TRENDINGDONE = "trendingDone";
    public static final String TRENDINGCHANGE = "trendingChange";
    public static final String TRENDINGSKIP = "trendingSkip";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trending);

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);

        bottomNavigationView.setSelectedItemId(R.id.nav_recipe);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch (menuItem.getItemId()) {
                    case R.id.nav_recipe:
                        onBackPressed();
                        return true;
                    case R.id.nav_calorie:
                        startActivity(new Intent(getApplicationContext()
                                ,Calorie.class));
                        overridePendingTransition(0, 0);
                        return true;
                    case R.id.nav_exercise:
                        startActivity(new Intent(getApplicationContext()
                                ,Exercise.class));
                        overridePendingTransition(0, 0);
                        return true;
                    case R.id.nav_profile:
                        startActivity(new Intent(getApplicationContext()
                                ,Profile.class));
                        overridePendingTransition(0, 0);
                        return true;
                    case R.id.nav_home:
                        startActivity(new Intent(getApplicationContext()
                                ,MainActivity.class));
                        overridePendingTransition(0, 0);
                        return true;
                }
                return false;
            }
        });
        closeTrendingButton = (Button) findViewById(R.id.trendingClose);
        likeButton = (Button) findViewById(R.id.trendingHeart);
        doneButton = (Button) findViewById(R.id.trendingDone);
        skipButton = (Button) findViewById(R.id.trendingSkip);
        changeButton = (Button) findViewById(R.id.trendingChange);

        heroImg = (ImageView) findViewById(R.id.image_trending);
        title = (TextView) findViewById(R.id.text_trending_title);
        summary = (TextView) findViewById(R.id.text_trending_summary_info);
        source = (TextView) findViewById(R.id.text_trending_source);
        ingredients = (TextView) findViewById(R.id.text_trending_ingredients_info);
        instructions = (TextView) findViewById(R.id.text_trending_instructions_info);
        nutrition = (TextView) findViewById(R.id.text_trending_nutrition_info);
        notes = (TextView) findViewById(R.id.text_trending_notes_info);
        closeTrendingButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        likeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (likeIsClicked) {
                    likeButton.setBackgroundDrawable(getResources().getDrawable(R.drawable.ic_not_liked_icon));
                    likeIsClicked = false;
                } else {
                    likeButton.setBackgroundDrawable(getResources().getDrawable(R.drawable.ic_liked_icon));
                    likeIsClicked = true;
                }
                saveData();
            }
        });

        doneButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (doneIsClicked) {
                    changeButton.setVisibility(View.VISIBLE);
                    changeButton.setText("Change");
                    changeButton.setEnabled(true);
                    skipButton.setVisibility(View.VISIBLE);
                    skipButton.setText("Skip");
                    skipButton.setEnabled(true);
                    doneButton.setVisibility(View.VISIBLE);
                    doneButton.setText("Done");
                    doneIsClicked = false;
                } else {
                    changeButton.setVisibility(View.GONE);
                    changeButton.setText("");
                    changeButton.setEnabled(false);
                    skipButton.setVisibility(View.GONE);
                    skipButton.setText("");
                    skipButton.setEnabled(false);
                    doneButton.setVisibility(View.VISIBLE);
                    doneButton.setText("Completed");
                    doneIsClicked = true;
                }
                saveData();
            }
        });
        skipButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (skipIsClicked) {
                    changeButton.setVisibility(View.VISIBLE);
                    changeButton.setText("Change");
                    changeButton.setEnabled(true);
                    doneButton.setVisibility(View.VISIBLE);
                    doneButton.setText("Done");
                    doneButton.setEnabled(true);
                    skipButton.setVisibility(View.VISIBLE);
                    skipButton.setText("Skip");
                    skipIsClicked = false;
                } else {
                    changeButton.setVisibility(View.GONE);
                    changeButton.setText("");
                    changeButton.setEnabled(false);
                    doneButton.setVisibility(View.GONE);
                    doneButton.setText("");
                    doneButton.setEnabled(false);
                    skipButton.setVisibility(View.VISIBLE);
                    skipButton.setText("Skipped");
                    skipIsClicked = true;
                }
                saveData();
            }
        });
        changeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                index++;
                skipButton.setVisibility(View.VISIBLE);
                skipButton.setText("Skip");
                skipButton.setEnabled(true);
                doneButton.setVisibility(View.VISIBLE);
                doneButton.setText("Done");
                doneButton.setEnabled(true);
                changeButton.setVisibility(View.VISIBLE);
                changeButton.setText("Changed");
                changeIsClicked = true;

                jsonParse();
                saveData();
            }
        });
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        firstStart = prefs.getBoolean(FIRSTSTART, true);
        if (firstStart) {
            saveData();
        } else {
            loadData();
        }
        mQueue = Volley.newRequestQueue(this);
        jsonParse();
    }
    public void saveData() {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        if (firstStart) {
            editor.putBoolean(FIRSTSTART, false);
        }
        editor.putInt(INDEXTRENDING, index);
        editor.putBoolean(TRENDINGHEART, likeIsClicked);
        editor.putBoolean(TRENDINGDONE, doneIsClicked);
        editor.putBoolean(TRENDINGSKIP, skipIsClicked);
        editor.putBoolean(TRENDINGCHANGE, changeIsClicked);
        editor.apply();
    }

    // Loads data
    public void loadData() {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        index = sharedPreferences.getInt(INDEXTRENDING, 0);
        likeIsClicked = sharedPreferences.getBoolean(TRENDINGHEART, false);
        doneIsClicked = sharedPreferences.getBoolean(TRENDINGDONE, false);
        skipIsClicked = sharedPreferences.getBoolean(TRENDINGSKIP, false);
        changeIsClicked = sharedPreferences.getBoolean(TRENDINGCHANGE, false);

        if(likeIsClicked) {
            likeButton.setBackgroundDrawable(getResources().getDrawable(R.drawable.ic_liked_icon));
        } else {
            likeButton.setBackgroundDrawable(getResources().getDrawable(R.drawable.ic_not_liked_icon));
        }
        if (doneIsClicked && !skipIsClicked) {
            changeButton.setVisibility(View.GONE);
            changeButton.setText("");
            changeButton.setEnabled(false);
            skipButton.setVisibility(View.GONE);
            skipButton.setText("");
            skipButton.setEnabled(false);
            doneButton.setVisibility(View.VISIBLE);
            doneButton.setText("Completed");
            doneButton.setEnabled(true);
        } else if (!doneIsClicked && !skipIsClicked) {
            doneButton.setVisibility(View.VISIBLE);
            doneButton.setText("Done");
            doneButton.setEnabled(true);
            changeButton.setVisibility(View.VISIBLE);
            changeButton.setText("Change");
            changeButton.setEnabled(true);
            skipButton.setVisibility(View.VISIBLE);
            skipButton.setText("Skip");
            skipButton.setEnabled(true);
        } else if (skipIsClicked && !doneIsClicked) {
            changeButton.setVisibility(View.GONE);
            changeButton.setText("");
            changeButton.setEnabled(false);
            skipButton.setVisibility(View.VISIBLE);
            skipButton.setText("Skipped");
            skipButton.setEnabled(true);
            doneButton.setVisibility(View.GONE);
            doneButton.setText("");
            doneButton.setEnabled(false);
        } else if (changeIsClicked && !skipIsClicked && !doneIsClicked) {
            skipButton.setVisibility(View.VISIBLE);
            skipButton.setText("Skip");
            skipButton.setEnabled(true);
            doneButton.setVisibility(View.VISIBLE);
            doneButton.setText("Done");
            doneButton.setEnabled(true);
            changeButton.setVisibility(View.VISIBLE);
            changeButton.setText("Changed");
        }
    }
    private void jsonParse() {

        String url = "https://hehexda3.s3.amazonaws.com/data/recipe.json";

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            JSONArray jsonArray = response.getJSONArray("trending");

                            if(index + 1 > jsonArray.length()) {
                                index = 0;
                            }
                            JSONObject trending = jsonArray.getJSONObject(index);

                            String recipeName = trending.getString("name");
                            String recipeSummary = trending.getString("summary");
                            String recipeSource = trending.getString("source");
                            String recipeIngredients = trending.getString("ingredients");
                            String recipeInstructions = trending.getString("instructions");
                            String recipeNutrition = trending.getString("nutrition");
                            String recipeNotes = trending.getString("notes");

                            title.setText(recipeName);
                            summary.setText(recipeSummary);
                            ingredients.setText(recipeIngredients);
                            instructions.setText(recipeInstructions);
                            nutrition.setText(recipeNutrition);
                            notes.setText(recipeNotes);

                            if (index == 0) {
                                heroImg.setImageResource(R.drawable.weet_bix_and_mango_smoothie_bowl);
                            } else if (index == 1) {
                                heroImg.setImageResource(R.drawable.peppered_steak_with_creamy_mushroom_sauce);
                            }
                            source.setClickable(true);
                            source.setMovementMethod(LinkMovementMethod.getInstance());
                            String link = "<a href='"+recipeSource+"'>"+ recipeSource +"</a>";
                            source.setText(Html.fromHtml(link));

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });
        mQueue.add(request);
    }
}