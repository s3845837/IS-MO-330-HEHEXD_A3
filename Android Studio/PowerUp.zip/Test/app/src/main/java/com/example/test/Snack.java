package com.example.test;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.text.Html;
import android.text.method.LinkMovementMethod;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class Snack extends AppCompatActivity {
    private RequestQueue mQueue;
    private ImageView heroImg;
    private TextView title;
    private TextView summary;
    private TextView source;
    private TextView ingredients;
    private TextView instructions;
    private TextView nutrition;
    private TextView notes;
    private int index = 0;


    private Button closeSnackButton;
    private Button doneButton;
    private boolean doneIsClicked;
    private Button skipButton;
    private boolean skipIsClicked;
    private Button changeButton;
    private boolean changeIsClicked;
    private Button likeButton;
    private boolean likeIsClicked;

    private boolean firstStart;
    public static final String INDEXSNACK = "indexSnack";
    public static final String FIRSTSTART = "firstStart";
    public static final String SNACKHEART = "snackHeart";
    public static final String SNACKDONE = "snackDone";
    public static final String SNACKCHANGE = "snackChange";
    public static final String SNACKSKIP = "snackSkip";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_snack);

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);

        bottomNavigationView.setSelectedItemId(R.id.nav_recipe);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch (menuItem.getItemId()) {
                    case R.id.nav_recipe:
                        onBackPressed();
                        return true;
                    case R.id.nav_calorie:
                        startActivity(new Intent(getApplicationContext()
                                ,Calorie.class));
                        overridePendingTransition(0, 0);
                        return true;
                    case R.id.nav_exercise:
                        startActivity(new Intent(getApplicationContext()
                                ,Exercise.class));
                        overridePendingTransition(0, 0);
                        return true;
                    case R.id.nav_profile:
                        startActivity(new Intent(getApplicationContext()
                                ,Profile.class));
                        overridePendingTransition(0, 0);
                        return true;
                    case R.id.nav_home:
                        startActivity(new Intent(getApplicationContext()
                                ,MainActivity.class));
                        overridePendingTransition(0, 0);
                        return true;
                }
                return false;
            }
        });
        closeSnackButton = (Button) findViewById(R.id.snackClose);
        likeButton = (Button) findViewById(R.id.snackHeart);
        doneButton = (Button) findViewById(R.id.snackDone);
        skipButton = (Button) findViewById(R.id.snackSkip);
        changeButton = (Button) findViewById(R.id.snackChange);

        heroImg = (ImageView) findViewById(R.id.image_snack);
        title = (TextView) findViewById(R.id.text_snack_title);
        summary = (TextView) findViewById(R.id.text_snack_summary_info);
        source = (TextView) findViewById(R.id.text_snack_source);
        ingredients = (TextView) findViewById(R.id.text_snack_ingredients_info);
        instructions = (TextView) findViewById(R.id.text_snack_instructions_info);
        nutrition = (TextView) findViewById(R.id.text_snack_nutrition_info);
        notes = (TextView) findViewById(R.id.text_snack_notes_info);



        closeSnackButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        likeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (likeIsClicked) {
                    likeButton.setBackgroundDrawable(getResources().getDrawable(R.drawable.ic_not_liked_icon));
                    likeIsClicked = false;
                } else {
                    likeButton.setBackgroundDrawable(getResources().getDrawable(R.drawable.ic_liked_icon));
                    likeIsClicked = true;
                }
                saveData();
            }
        });

        doneButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (doneIsClicked) {
                    changeButton.setVisibility(View.VISIBLE);
                    changeButton.setText("Change");
                    changeButton.setEnabled(true);
                    skipButton.setVisibility(View.VISIBLE);
                    skipButton.setText("Skip");
                    skipButton.setEnabled(true);
                    doneButton.setVisibility(View.VISIBLE);
                    doneButton.setText("Done");
                    doneIsClicked = false;
                } else {
                    changeButton.setVisibility(View.GONE);
                    changeButton.setText("");
                    changeButton.setEnabled(false);
                    skipButton.setVisibility(View.GONE);
                    skipButton.setText("");
                    skipButton.setEnabled(false);
                    doneButton.setVisibility(View.VISIBLE);
                    doneButton.setText("Completed");
                    doneIsClicked = true;
                }
                saveData();
            }
        });
        skipButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (skipIsClicked) {
                    changeButton.setVisibility(View.VISIBLE);
                    changeButton.setText("Change");
                    changeButton.setEnabled(true);
                    doneButton.setVisibility(View.VISIBLE);
                    doneButton.setText("Done");
                    doneButton.setEnabled(true);
                    skipButton.setVisibility(View.VISIBLE);
                    skipButton.setText("Skip");
                    skipIsClicked = false;
                } else {
                    changeButton.setVisibility(View.GONE);
                    changeButton.setText("");
                    changeButton.setEnabled(false);
                    doneButton.setVisibility(View.GONE);
                    doneButton.setText("");
                    doneButton.setEnabled(false);
                    skipButton.setVisibility(View.VISIBLE);
                    skipButton.setText("Skipped");
                    skipIsClicked = true;
                }
                saveData();
            }
        });
        changeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                index++;
                skipButton.setVisibility(View.VISIBLE);
                skipButton.setText("Skip");
                skipButton.setEnabled(true);
                doneButton.setVisibility(View.VISIBLE);
                doneButton.setText("Done");
                doneButton.setEnabled(true);
                changeButton.setVisibility(View.VISIBLE);
                changeButton.setText("Changed");
                changeIsClicked = true;

                jsonParse();
                saveData();
            }
        });
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        firstStart = prefs.getBoolean(FIRSTSTART, true);
        if (firstStart) {
            saveData();
        } else {
            loadData();
        }
        mQueue = Volley.newRequestQueue(this);
        jsonParse();
    }
    public void saveData() {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        if (firstStart) {
            editor.putBoolean(FIRSTSTART, false);
        }
        editor.putInt(INDEXSNACK, index);
        editor.putBoolean(SNACKHEART, likeIsClicked);
        editor.putBoolean(SNACKDONE, doneIsClicked);
        editor.putBoolean(SNACKSKIP, skipIsClicked);
        editor.putBoolean(SNACKCHANGE, changeIsClicked);
        editor.apply();
    }

    // Loads data
    public void loadData() {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        index = sharedPreferences.getInt(INDEXSNACK, 0);
        likeIsClicked = sharedPreferences.getBoolean(SNACKHEART, false);
        doneIsClicked = sharedPreferences.getBoolean(SNACKDONE, false);
        skipIsClicked = sharedPreferences.getBoolean(SNACKSKIP, false);
        changeIsClicked = sharedPreferences.getBoolean(SNACKCHANGE, false);

        if(likeIsClicked) {
            likeButton.setBackgroundDrawable(getResources().getDrawable(R.drawable.ic_liked_icon));
        } else {
            likeButton.setBackgroundDrawable(getResources().getDrawable(R.drawable.ic_not_liked_icon));
        }
        if (doneIsClicked && !skipIsClicked) {
            changeButton.setVisibility(View.GONE);
            changeButton.setText("");
            changeButton.setEnabled(false);
            skipButton.setVisibility(View.GONE);
            skipButton.setText("");
            skipButton.setEnabled(false);
            doneButton.setVisibility(View.VISIBLE);
            doneButton.setText("Completed");
            doneButton.setEnabled(true);
        } else if (!doneIsClicked && !skipIsClicked) {
            doneButton.setVisibility(View.VISIBLE);
            doneButton.setText("Done");
            doneButton.setEnabled(true);
            changeButton.setVisibility(View.VISIBLE);
            changeButton.setText("Change");
            changeButton.setEnabled(true);
            skipButton.setVisibility(View.VISIBLE);
            skipButton.setText("Skip");
            skipButton.setEnabled(true);
        } else if (skipIsClicked && !doneIsClicked) {
            changeButton.setVisibility(View.GONE);
            changeButton.setText("");
            changeButton.setEnabled(false);
            skipButton.setVisibility(View.VISIBLE);
            skipButton.setText("Skipped");
            skipButton.setEnabled(true);
            doneButton.setVisibility(View.GONE);
            doneButton.setText("");
            doneButton.setEnabled(false);
        } else if (changeIsClicked && !skipIsClicked && !doneIsClicked) {
            skipButton.setVisibility(View.VISIBLE);
            skipButton.setText("Skip");
            skipButton.setEnabled(true);
            doneButton.setVisibility(View.VISIBLE);
            doneButton.setText("Done");
            doneButton.setEnabled(true);
            changeButton.setVisibility(View.VISIBLE);
            changeButton.setText("Changed");
        }
    }
    private void jsonParse() {

        String url = "https://hehexda3.s3.amazonaws.com/data/recipe.json";

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            JSONArray jsonArray = response.getJSONArray("snack");

                            if(index + 1 > jsonArray.length()) {
                                index = 0;
                            }
                            JSONObject snack = jsonArray.getJSONObject(index);

                            String recipeName = snack.getString("name");
                            String recipeSummary = snack.getString("summary");
                            String recipeSource = snack.getString("source");
                            String recipeIngredients = snack.getString("ingredients");
                            String recipeInstructions = snack.getString("instructions");
                            String recipeNutrition = snack.getString("nutrition");
                            String recipeNotes = snack.getString("notes");

                            title.setText(recipeName);
                            summary.setText(recipeSummary);
                            ingredients.setText(recipeIngredients);
                            instructions.setText(recipeInstructions);
                            nutrition.setText(recipeNutrition);
                            notes.setText(recipeNotes);

                            if (index == 0) {
                                heroImg.setImageResource(R.drawable.fruit_and_nut_snack_mix);
                            } else if (index == 1) {
                                heroImg.setImageResource(R.drawable.snack_box_muffins);
                            }
                            source.setClickable(true);
                            source.setMovementMethod(LinkMovementMethod.getInstance());
                            String link = "<a href='"+recipeSource+"'>"+ recipeSource +"</a>";
                            source.setText(Html.fromHtml(link));

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });
        mQueue.add(request);
    }
}